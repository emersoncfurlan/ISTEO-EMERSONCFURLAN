import React, { useEffect, useState } from "react";

function App() {
  const [users, setUsers] = useState([]);

  interface User {
    id: number;
    name: string;
    cpf: string;
    email: string;
    password: string;
  }

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    try {
      const response = await fetch("http://127.0.0.1:8080/users");
      const data = await response.json();
      console.log(data);
      setUsers(data);
    } catch (error) {
      console.log("Erro ao carregar usuários:", error);
    }
  }

  return (
    <>
      <div className="grid-container">
        <div className="grid-item grid-header">ID</div>
        <div className="grid-item grid-header">Nome</div>
        <div className="grid-item grid-header">CPF</div>
        <div className="grid-item grid-header">Email</div>
        <div className="grid-item grid-header">Senha</div>
        <div className="grid-item grid-header">Ações</div>
        {users.map((user: User) => (
          <div className="grid-item" key={user.id}>
            <p>{user.id}</p>
            <p>{user.name}</p>
            <p>{user.cpf}</p>
            <p>{user.email}</p>
            <p>{user.password}</p>
            <div className="grid-actions">
              {/* <button className="grid-button" onClick={`editUser(${user.id}`}>Editar</button> */}
              {/* <button className="grid-button" onClick={`deleteUser(${user.id}`}>Excluir</button> */}
            </div>
          </div>
        ))}
      </div>
      {/* <button onClick="addUser()">Adicionar Usuário</button> */}
    </>
  );
}
export default App;
