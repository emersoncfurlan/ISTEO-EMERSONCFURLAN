import React from 'react';
import { FiLogIn } from 'react-icons/fi';
import { Link } from 'react-router-dom';

import './styles.css';

const Home = () => {
    return(
        //div#page-home
        <div id="page-home">
            <div className="content">
                <header>
                </header>

                <main>
                    <h1>ISTEO</h1>
                    <p> Prova Prática - EMERSON CHIABAI FURLAN</p>
                    <Link to="/users">
                        <span>
                            <FiLogIn/>
                        </span>
                        <strong>Acesse a página de Listagem dos Usuários</strong>
                    </Link>
                </main>
            </div>
        </div>
    );
};

export default Home;