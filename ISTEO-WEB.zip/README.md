# ISTEO - Web
Para executar o projeto primeiro execute 
'yarn' ou 'npm install' para instalar as depencias

após a instalaçao execute:
'yarn start' ou 'npm start' para execucao do projeto

Acesse a Rota: localhost:3000
Listagem de usuários na rota localhost:3000/users