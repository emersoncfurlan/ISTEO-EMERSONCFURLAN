package com.isteo.isteoapi.controller;

import com.isteo.isteoapi.entity.User;
import com.isteo.isteoapi.entity.exceptions.UserNotFound;
import jakarta.transaction.Transactional;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import com.isteo.isteoapi.repository.UserRepository;

@RestController
@RequestMapping("/users")
public class UserController {
  private final UserRepository userRepository;

  public UserController(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @GetMapping
  public ResponseEntity<?> getUser(){
    return ResponseEntity.ok(userRepository.findAll());
  }
  @PostMapping()
  public ResponseEntity<?> createUser(@RequestBody User user){
    var userFound = userRepository.save(user);
    return ResponseEntity.ok(userFound);
  }
  @PutMapping
  public ResponseEntity<?> updateUser(@RequestBody User user){
    var userFound = userRepository.findByCpf(user.getCpf()).orElseThrow(UserNotFound::new);
    userFound.setName(user.getName());
    userFound.setCpf(user.getCpf());
    return ResponseEntity.ok(userRepository.save(userFound));
  }
  @PutMapping("/updatePwd")
  public ResponseEntity<?> updatePassword(@RequestBody User user){
    var userFound = userRepository.findByCpf(user.getCpf()).orElseThrow(UserNotFound::new);
    userFound.setPassword(user.getPassword());
    return ResponseEntity.ok(userRepository.save(userFound));
  }
  @PutMapping("/updateEmail")
  public ResponseEntity<?> updateEmail(@RequestBody User user){
    var userFound = userRepository.findByCpf(user.getCpf()).orElseThrow(UserNotFound::new);
    userFound.setEmail(user.getEmail());
    return ResponseEntity.ok(userRepository.save(userFound));
  }
  @DeleteMapping
  @Transactional
  public ResponseEntity<?> removeUser(@RequestBody User user){
    userRepository.delete(userRepository.findByCpf(user.getCpf()).orElseThrow(UserNotFound::new));
    return ResponseEntity.ok("Usuário excluido com sucesso!");
  }

}