package com.isteo.isteoapi.repository;

import com.isteo.isteoapi.entity.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
  User findByName(@Param("name") String name);
  Optional<User> findByCpf(@Param("cpf") String cpf);


}
